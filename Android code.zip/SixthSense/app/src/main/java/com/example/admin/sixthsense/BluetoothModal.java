package com.example.admin.sixthsense;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.InputStream;
import java.io.OutputStream;

public class BluetoothModal {

    static BluetoothAdapter ba;
    static BluetoothSocket bs;
    static BluetoothDevice bd;

    static InputStream is;
    static OutputStream os;

    public static InputStream getIs() {
        return is;
    }

    public static void setIs(InputStream is) {
        BluetoothModal.is = is;
    }

    public static OutputStream getOs() {
        return os;
    }

    public static void setOs(OutputStream os) {
        BluetoothModal.os = os;
    }

    public BluetoothAdapter getBa() {
        return ba;
    }

    public void setBa(BluetoothAdapter ba) {
        this.ba = ba;
    }

    public BluetoothSocket getBs() {
        return bs;
    }

    public void setBs(BluetoothSocket bs) {
        this.bs = bs;
    }

    public BluetoothDevice getBd() {
        return bd;
    }

    public void setBd(BluetoothDevice bd) {
        this.bd = bd;
    }
}
