package com.example.admin.sixthsense;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SwitchCompat;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class GloveMode extends AppCompatActivity {

    BluetoothAdapter ba;
    BluetoothDevice bd;
    BluetoothSocket bs;

    InputStream is;
    OutputStream os;

    SwitchCompat lightSwitch1,lightSwitch2,fanSwitch;

    ImageView imglight1,imglight2,imgfan;

    Button openbt,closebt;
    Button showsensordata;

    Thread workerThread;
    byte[] readBuffer;
    int readBufferPosition;
    boolean stopWorker;

    TelephonyManager manager;
    StatePhoneReceiver myPhoneStateListener;
    boolean callFromApp = false; // To control the call has been made from the application
    boolean callFromOffHook = false; // To control the change to idle state is from the app call

    BluetoothModal modal=new BluetoothModal();

    TextView sensor1,sensor2;
    RelativeLayout rl1;
    RelativeLayout rl2;
    int showdataflag=0;

    String phone = "+919834008528";
    MediaPlayer mp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_glove_mode);

        ba=modal.getBa();
        bd=modal.getBd();
        bs=modal.getBs();
        is=modal.getIs();
        os=modal.getOs();

        openbt=(Button)findViewById(R.id.openbt);
        closebt=(Button)findViewById(R.id.closebt);
        showsensordata=(Button)findViewById(R.id.showsensordata);
        rl1=(RelativeLayout)findViewById(R.id.rl1);
        rl2=(RelativeLayout)findViewById(R.id.rl2);
        sensor1=(TextView)findViewById(R.id.sensor1);
        sensor2=(TextView)findViewById(R.id.sensor2);

        showsensordata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showdataflag=1;
                rl1.setVisibility(View.GONE);
                rl2.setVisibility(View.VISIBLE);

            }
        });


        lightSwitch1=(SwitchCompat)findViewById(R.id.lightSwitch1);
        lightSwitch1.setChecked(false);
        lightSwitch2=(SwitchCompat)findViewById(R.id.lightSwitch2);
        lightSwitch2.setChecked(false);
        fanSwitch=(SwitchCompat)findViewById(R.id.fanSwitch);
        fanSwitch.setChecked(false);

        imglight1=(ImageView)findViewById(R.id.imglight1);
        imglight2=(ImageView)findViewById(R.id.imglight2);
        imgfan=(ImageView)findViewById(R.id.imgfan);

        openbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try
                {
                    findBT();
                    openBT();
                }
                catch (Exception e)
                {

                }
            }
        });

        closebt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try
                {
                    closeBT();
                }
                catch (Exception e)
                {

                }
            }
        });

        lightSwitch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {

                if(isChecked){

                    imglight1.setBackgroundColor(Color.parseColor("#FFFF00"));


                }else{

                    imglight1.setBackgroundColor(Color.parseColor("#000000"));

                }

            }
        });
        lightSwitch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {

                if(isChecked){

                    imglight2.setBackgroundColor(Color.parseColor("#FFFF00"));

                }else{

                    imglight2.setBackgroundColor(Color.parseColor("#000000"));

                }

            }
        });
        fanSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){

                    imgfan.setBackgroundColor(Color.parseColor("#FFFF00"));

                }else{

                    imgfan.setBackgroundColor(Color.parseColor("#000000"));

                }

            }
        });

        if(ba==null)
        {
            ba = BluetoothAdapter.getDefaultAdapter();
            modal.setBa(ba);
        }
        if(bd!=null&&bs!=null)
        {
            try {
                recieve();
            }catch (Exception e){}
        }
    }

    public void call() {

        manager.listen(myPhoneStateListener,
                PhoneStateListener.LISTEN_CALL_STATE); // start listening to the phone changes
        callFromApp = true;
        Intent i = new Intent(android.content.Intent.ACTION_CALL,
                Uri.parse("tel:+" + phone)); // Make the call
        startActivity(i);

    }
    // Monitor for changes to the state of the phone
    public class StatePhoneReceiver extends PhoneStateListener {
        Context context;

        public StatePhoneReceiver(Context context) {
            this.context = context;
        }

        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            super.onCallStateChanged(state, incomingNumber);

            switch (state) {

                case TelephonyManager.CALL_STATE_OFFHOOK: //Call is established
                    if (callFromApp) {
                        callFromApp = false;
                        callFromOffHook = true;

                        try {
                            Thread.sleep(500); // Delay 0,5 seconds to handle better turning on loudspeaker
                        } catch (InterruptedException e) {
                        }

                        //Activate loudspeaker
                        AudioManager audioManager = (AudioManager)
                                getSystemService(Context.AUDIO_SERVICE);
                        audioManager.setMode(AudioManager.MODE_IN_CALL);
                        audioManager.setSpeakerphoneOn(true);
                    }
                    break;

                case TelephonyManager.CALL_STATE_IDLE: //Call is finished
                    if (callFromOffHook) {
                        callFromOffHook = false;
                        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                        audioManager.setMode(AudioManager.MODE_NORMAL); //Deactivate loudspeaker
                        manager.listen(myPhoneStateListener, // Remove listener
                                PhoneStateListener.LISTEN_NONE);
                    }
                    break;
            }
        }
    }
    void findBT()throws Exception {

        Set<BluetoothDevice> paired = ba.getBondedDevices();
        if (paired.size() > 0) {
            for (BluetoothDevice dev : paired) {
                if (dev.getName().equals("HC-06")) {

                    bd = dev;
                    modal.setBd(bd);
                    break;

                }
            }
        }
    }
    void openBT()throws Exception
    {
        UUID uuid= UUID.fromString("1101-0000-1000-8000-00805f9b34fb");
        bs=bd.createRfcommSocketToServiceRecord(uuid);
        bs.connect();
        is=bs.getInputStream();
        os=bs.getOutputStream();
        modal.setBs(bs);
        modal.setIs(is);
        modal.setOs(os);
        recieve();
        Toast.makeText(this, "Socket Opened", Toast.LENGTH_LONG).show();
    }
    void recieve() throws Exception
    {

        final Handler handler = new Handler();
        final byte delimiter = 32;

        stopWorker = false;
        readBufferPosition = 0;
        readBuffer = new byte[1024];
        workerThread = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopWorker)
                {
                    try
                    {
                        int bytesAvailable = is.available();
                        if(bytesAvailable > 0)
                        {
                            byte[] packetBytes = new byte[bytesAvailable];
                            is.read(packetBytes);
                            for(int i=0;i<bytesAvailable;i++)
                            {
                                byte b = packetBytes[i];
                                if(b == delimiter)
                                {
                                    byte[] encodedBytes = new byte[readBufferPosition];
                                    System.arraycopy(readBuffer, 0, encodedBytes, 0, encodedBytes.length);
                                    final String data = new String(encodedBytes, "US-ASCII");
                                    readBufferPosition = 0;

                                    Log.d("TAG", "data: "+data);

                                    handler.post(new Runnable()
                                    {
                                        public void run()
                                        {

                                            if(data.equals("A"))
                                            {
                                                lightSwitch1.setChecked(true);
                                            }
                                            else if(data.equals("B"))
                                            {
                                                lightSwitch1.setChecked(false);
                                            }
                                            else if(data.equals("C"))
                                            {
                                                call();
                                            }
                                            else if(data.equals("7"))
                                            {
                                                lightSwitch2.setChecked(true);
                                            }
                                            else if(data.equals("8"))
                                            {
                                                lightSwitch2.setChecked(false);
                                            }
                                            else if(data.equals("G"))
                                            {
                                                fanSwitch.setChecked(true);
                                            }
                                            else if(data.equals("H"))
                                            {
                                                fanSwitch.setChecked(false);
                                            }
                                            else if(data.equals("O"))
                                            {
                                                fanSwitch.setChecked(false);
                                                lightSwitch2.setChecked(false);
                                                lightSwitch1.setChecked(false);
                                            }

                                            else
                                            {
                                                if(data.length()==1)
                                                {
                                                    sensor2.setText(data);

                                                    float temp=Float.parseFloat(data);
                                                    if(temp>35) {
                                                        mp = MediaPlayer.create(GloveMode.this, R.raw.fire);
                                                        mp.start();
                                                    }
                                                    else
                                                        if(mp!=null)
                                                            mp.stop();
                                                }
                                                else
                                                {
                                                    sensor1.setText(data);
                                                }
                                            }
                                        }
                                    });
                                }
                                else
                                {
                                    readBuffer[readBufferPosition++] = b;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        stopWorker = true;
                    }
                }
            }
        });

        workerThread.start();


    }
    void closeBT()throws Exception
    {
        stopWorker = true;
        is.close();
        bs.close();

        Toast.makeText(this,"Socket closed",Toast.LENGTH_LONG).show();

    }
    @Override
    public void onBackPressed() {

        if(showdataflag==0) {
            super.onBackPressed();
            mp.release();
        }
        else
        {
            showdataflag=0;
            rl1.setVisibility(View.VISIBLE);
            rl2.setVisibility(View.GONE);

        }

    }
}
