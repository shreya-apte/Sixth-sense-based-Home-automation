package com.example.admin.sixthsense;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button glovemode=(Button)findViewById(R.id.glovemode);
        //Button sphonemode=(Button)findViewById(R.id.sphonemode);
        glovemode.setOnClickListener(this);
        //sphonemode.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {

        if(v.getId()==R.id.glovemode)
        {
            Intent intent=new Intent(this,GloveMode.class);
            startActivity(intent);
        }
        /*else
        {
            Intent intent=new Intent(this,SPhoneMode.class);
            startActivity(intent);
        }*/
    }
}
